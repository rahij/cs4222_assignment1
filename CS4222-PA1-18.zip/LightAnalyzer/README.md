Light Analyzer
===================

Setup:

 - Clone the repository
 - Choose 'Open an existing Android Studio Project' in Android Studio
 - Click Run
